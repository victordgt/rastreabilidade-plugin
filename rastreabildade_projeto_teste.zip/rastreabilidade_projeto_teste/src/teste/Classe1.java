package teste;
import rastreabilidade.CasoDeUso;
import rastreabilidade.RegraDeNegocio;

@CasoDeUso(nome="chave-caso-de-uso-1", autor="Victor Torres", versao="1.0")
@RegraDeNegocio(identificador="chave-regra-de-negocio-1")

public class Classe1 {

}
