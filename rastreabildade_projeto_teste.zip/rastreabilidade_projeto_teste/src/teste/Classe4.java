package teste;
import rastreabilidade.CasoDeUso;
import rastreabilidade.RegraDeNegocio;

@CasoDeUso(nome="chave-caso-de-uso-3", autor="Victor Torres", versao="1.0")
@RegraDeNegocio(identificador="chave-regra-de-negocio-2")
public class Classe4 {
	
	public static void main(String[] args) {
		
	}

}
