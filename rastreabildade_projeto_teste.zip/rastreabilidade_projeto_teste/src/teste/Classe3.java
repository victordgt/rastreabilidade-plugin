package teste;

import rastreabilidade.CasoDeUso;

@CasoDeUso(nome="chave-caso-de-uso-1", autor="Victor Torres", versao="1.0")
public class Classe3 {

}
