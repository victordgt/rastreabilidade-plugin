package teste;
import rastreabilidade.CasoDeUso;

@CasoDeUso(nome="chave-caso-de-uso-2", autor="Victor Torres", versao="1.0")
public class Classe2 {

	public void teste() {
		
	}

}
